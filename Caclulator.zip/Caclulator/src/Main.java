import javax.swing.*;

/**
 * @author Дмитро Українець
 * @version 1.1
 * @since 12.05.2023
 * @File: Calculator
 * @Overwrite: В цій програмі я намагаюсь створити калькулятор з графічним інтерфейсом користувача, який має два режими.
 */
public class Main {

    /** Головний метод програми. */
    public static void main(String[] args) {
        CalculatorGraphic calculator = new CalculatorGraphic(1);
        calculator.setVisible(true);
        calculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}